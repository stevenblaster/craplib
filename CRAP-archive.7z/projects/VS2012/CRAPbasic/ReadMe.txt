﻿========================================================================
    STATISCHE BIBLIOTHEK: CRAPbasic-Projektübersicht
========================================================================

Dieses CRAPbasic-Bibliotheksprojekt wurde vom 
Anwendungs-Assistenten für Sie erstellt.

Es wurden keine Quelldateien als Teil des Projekts erstellt.


CRAPbasic.vcxproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem 
    Anwendungs-Assistenten generiert werden.
    Sie enthält Informationen zur Visual C++-Version, mit der die Datei 
    generiert wurde, sowie Informationen zu Plattformen, Konfigurationen und 
    Projektfunktionen, die mit dem Anwendungs-Assistenten ausgewählt wurden.

CRAPbasic.vcxproj.filters
    Dies ist die Filterdatei für VC++-Projekte, die mithilfe eines 
    Anwendungs-Assistenten erstellt werden. 
    Sie enthält Informationen über die Zuordnung zwischen den Dateien im 
    Projekt und den Filtern. Diese Zuordnung wird in der IDE zur Darstellung 
    der Gruppierung von Dateien mit ähnlichen Erweiterungen unter einem 
    bestimmten Knoten verwendet (z. B. sind CPP-Dateien dem Filter 
    "Quelldateien" zugeordnet).

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent weist Sie mit "TODO:"-Kommentaren auf Teile des
Quellcodes hin, die Sie ergänzen oder anpassen sollten.

/////////////////////////////////////////////////////////////////////////////
