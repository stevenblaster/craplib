var structcrap_1_1has__vtable_1_1test__class =
[
    [ "test_class", "structcrap_1_1has__vtable_1_1test__class.html#a6e4ee5125a96ae1e7d9ca1c64c4cd8fe", null ],
    [ "~test_class", "structcrap_1_1has__vtable_1_1test__class.html#ac1ec56b0a5223d91214a50cba6acd28f", null ]
];