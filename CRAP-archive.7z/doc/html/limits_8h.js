var limits_8h =
[
    [ "limits", "structcrap_1_1limits.html", "structcrap_1_1limits" ],
    [ "limits< b8 >", "structcrap_1_1limits_3_01b8_01_4.html", "structcrap_1_1limits_3_01b8_01_4" ],
    [ "limits< c8 >", "structcrap_1_1limits_3_01c8_01_4.html", "structcrap_1_1limits_3_01c8_01_4" ],
    [ "limits< i8 >", "structcrap_1_1limits_3_01i8_01_4.html", "structcrap_1_1limits_3_01i8_01_4" ],
    [ "limits< u8 >", "structcrap_1_1limits_3_01u8_01_4.html", "structcrap_1_1limits_3_01u8_01_4" ],
    [ "limits< i16 >", "structcrap_1_1limits_3_01i16_01_4.html", "structcrap_1_1limits_3_01i16_01_4" ],
    [ "limits< u16 >", "structcrap_1_1limits_3_01u16_01_4.html", "structcrap_1_1limits_3_01u16_01_4" ],
    [ "limits< i32 >", "structcrap_1_1limits_3_01i32_01_4.html", "structcrap_1_1limits_3_01i32_01_4" ],
    [ "limits< u32 >", "structcrap_1_1limits_3_01u32_01_4.html", "structcrap_1_1limits_3_01u32_01_4" ],
    [ "limits< i64 >", "structcrap_1_1limits_3_01i64_01_4.html", "structcrap_1_1limits_3_01i64_01_4" ],
    [ "limits< u64 >", "structcrap_1_1limits_3_01u64_01_4.html", "structcrap_1_1limits_3_01u64_01_4" ],
    [ "limits< f32 >", "structcrap_1_1limits_3_01f32_01_4.html", "structcrap_1_1limits_3_01f32_01_4" ],
    [ "limits< f64 >", "structcrap_1_1limits_3_01f64_01_4.html", "structcrap_1_1limits_3_01f64_01_4" ],
    [ "CRAP_CONTROL_LIMITS_H", "limits_8h.html#ae514b652c2cc3cbb820c43ab791e40a8", null ]
];