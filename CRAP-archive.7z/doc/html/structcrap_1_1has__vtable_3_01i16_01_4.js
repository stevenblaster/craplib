var structcrap_1_1has__vtable_3_01i16_01_4 =
[
    [ "RESULT", "structcrap_1_1has__vtable_3_01i16_01_4.html#a660892f8feaf9d934ab8d3d202f65b8a", null ]
];