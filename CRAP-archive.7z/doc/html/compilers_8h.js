var compilers_8h =
[
    [ "CRAP_COMPILER_NAME", "compilers_8h.html#a477b9dbf38102bec988ebb0b6beb19c3", null ],
    [ "CRAP_COMPILER_UNKNOWN", "compilers_8h.html#aa2f3ddb2c18b14ac78c4306b0f74c9f2", null ],
    [ "CRAP_CONFIG_COMPILERS_H", "compilers_8h.html#aaa33868ff1f4b9977357928ea089a405", null ],
    [ "CRAP_CPP", "compilers_8h.html#ad5edcf4fb82e86ea9831abb472bf3e40", null ],
    [ "CRAP_INLINE", "compilers_8h.html#a5a40526b8d842e7ff731509998bb0f1c", null ],
    [ "CRAP_TEMPLATE_CONST_FIX", "compilers_8h.html#a5dd91cccfe66c6ba2c35488cb1b7631f", null ],
    [ "compiler_type", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067", [
      [ "gcc", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067a622d828c592f48409bcab1c21220d317", null ],
      [ "vc", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067a78c36762f3b9c3455946cf3e3021879d", null ],
      [ "borland", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067aba75e81d00209e8acc8aa3b616a24beb", null ],
      [ "intel", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067a5eccccfad078ff77b5d6a625768aed79", null ],
      [ "unknown_compiler", "compilers_8h.html#a1118686d0b1bada904e097ebb2799067acc56888524d023c251551fc013114194", null ]
    ] ],
    [ "compiler", "compilers_8h.html#ae115b1e00770886caf2a9b18436dee7e", null ]
];