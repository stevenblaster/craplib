var pair_8h =
[
    [ "pair", "structcrap_1_1pair.html", "structcrap_1_1pair" ],
    [ "CRAP_CONTAINER_PAIR_H", "pair_8h.html#abe507fcea425a0eb3d5bf79dcc3f81a0", null ],
    [ "make_pair", "pair_8h.html#a8d4a14194dcafc95ae3d1eb4fa1eeb37", null ]
];