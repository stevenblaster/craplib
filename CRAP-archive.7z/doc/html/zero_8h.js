var zero_8h =
[
    [ "zero", "structcrap_1_1zero.html", "structcrap_1_1zero" ],
    [ "zero< f32 >", "structcrap_1_1zero_3_01f32_01_4.html", "structcrap_1_1zero_3_01f32_01_4" ],
    [ "zero< f64 >", "structcrap_1_1zero_3_01f64_01_4.html", "structcrap_1_1zero_3_01f64_01_4" ],
    [ "CRAP_CONTROL_ZERO_H", "zero_8h.html#ac25747c653b2fce5ea2b299f9c29395a", null ]
];