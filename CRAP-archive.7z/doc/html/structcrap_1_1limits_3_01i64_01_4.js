var structcrap_1_1limits_3_01i64_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01i64_01_4.html#a1c75e13842bd5be8dc607703aa3bde20", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01i64_01_4.html#abc50902329af13ea9041e31b99530519", null ],
    [ "MAX", "structcrap_1_1limits_3_01i64_01_4.html#af68dda1c50195c3f58e4517fc21d69f4", null ],
    [ "MIN", "structcrap_1_1limits_3_01i64_01_4.html#a50f4434a55e01e7dae98941d5595a6b3", null ]
];