var structcrap_1_1less =
[
    [ "operator()", "structcrap_1_1less.html#af32d1b6b510d16a5ad7732cae0ceb4b8", null ]
];