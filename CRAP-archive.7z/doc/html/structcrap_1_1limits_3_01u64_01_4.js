var structcrap_1_1limits_3_01u64_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01u64_01_4.html#a3ea308607ff41e00fd16ddd0e9fbdb2d", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01u64_01_4.html#ab32b1932605073ebb8b29cfa59ea1d6d", null ],
    [ "MAX", "structcrap_1_1limits_3_01u64_01_4.html#a948bee8825f44d2d1ca308119a564f8d", null ],
    [ "MIN", "structcrap_1_1limits_3_01u64_01_4.html#a307736ccb34fa4e61dc2e993f1e029db", null ]
];