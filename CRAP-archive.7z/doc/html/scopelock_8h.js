var scopelock_8h =
[
    [ "scope_lock", "classcrap_1_1scope__lock.html", "classcrap_1_1scope__lock" ],
    [ "CRAP_THREADING_SCOPELOCK_H", "scopelock_8h.html#adeac277671a6836ed824b58f3401453b", null ],
    [ "SCOPE_MUTEX", "scopelock_8h.html#adf686fa25538c8d1e8abc2f99808a7ac", null ]
];