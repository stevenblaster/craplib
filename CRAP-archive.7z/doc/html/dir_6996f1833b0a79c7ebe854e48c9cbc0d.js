var dir_6996f1833b0a79c7ebe854e48c9cbc0d =
[
    [ "staticstring.h", "staticstring_8h.html", "staticstring_8h" ],
    [ "string.h", "string_8h.html", "string_8h" ]
];