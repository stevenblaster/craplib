var structcrap_1_1limits_3_01i16_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01i16_01_4.html#a9d0b16f84b3813fe161bcd5c4758750d", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01i16_01_4.html#acaf692f3f9189b8439fda32001539b55", null ],
    [ "MAX", "structcrap_1_1limits_3_01i16_01_4.html#a13ea6e73f00832ef4ee180905c515a50", null ],
    [ "MIN", "structcrap_1_1limits_3_01i16_01_4.html#aa889fd67d3f189c3088083ee7fcc864d", null ]
];