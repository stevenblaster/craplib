var structcrap_1_1has__vtable_3_01i64_01_4 =
[
    [ "RESULT", "structcrap_1_1has__vtable_3_01i64_01_4.html#afd19afa10a496b172943d1324fcdf08b", null ]
];