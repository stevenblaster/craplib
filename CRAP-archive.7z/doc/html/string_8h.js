var string_8h =
[
    [ "CRAP_TYPES_STRING_H", "string_8h.html#a153b3ef06b69f678f0d25eaf82e9f60c", null ],
    [ "string", "string_8h.html#a0fce4d4cb2ab9ac432be9d65ed985e89", null ]
];