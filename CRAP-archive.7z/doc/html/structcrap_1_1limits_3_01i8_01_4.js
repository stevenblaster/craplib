var structcrap_1_1limits_3_01i8_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01i8_01_4.html#a51f3d21ce69742a7573fccdefbcd850a", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01i8_01_4.html#aaaca3b4f389d55b8d647c522f13c1c37", null ],
    [ "MAX", "structcrap_1_1limits_3_01i8_01_4.html#a9a112176e132c99e9a942394b144358d", null ],
    [ "MIN", "structcrap_1_1limits_3_01i8_01_4.html#af0166184f7c1640d6c55d91aec23122c", null ]
];