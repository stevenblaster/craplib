var structcrap_1_1has__vtable_3_01f64_01_4 =
[
    [ "RESULT", "structcrap_1_1has__vtable_3_01f64_01_4.html#abf7cca7fd109cbadc33b642483ecaa69", null ]
];