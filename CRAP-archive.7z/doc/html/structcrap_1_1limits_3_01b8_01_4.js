var structcrap_1_1limits_3_01b8_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01b8_01_4.html#ade07f706657b5325f1d424710e1451c3", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01b8_01_4.html#a08b3d51e6a03bb60785009fd3d68077b", null ],
    [ "MAX", "structcrap_1_1limits_3_01b8_01_4.html#abb6122e7510a3d43e1e95a2543af6c0d", null ],
    [ "MIN", "structcrap_1_1limits_3_01b8_01_4.html#ad7cee023c6e3c4ee5f1827e5becc110d", null ]
];