var structcrap_1_1zero_3_01f32_01_4 =
[
    [ "VALUE", "structcrap_1_1zero_3_01f32_01_4.html#a8f273005ab22247cb70022adac98953e", null ]
];