var math_2math_8h =
[
    [ "math", "classcrap_1_1math.html", "classcrap_1_1math" ],
    [ "CRAP_MATH_MATH_H", "math_2math_8h.html#a41ff98e0b00d2702dafd40c98b193d2c", null ]
];