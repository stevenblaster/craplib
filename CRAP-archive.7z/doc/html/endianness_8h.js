var endianness_8h =
[
    [ "CRAP_CONFIG_ENDIAN_H", "endianness_8h.html#a6ab70f76fe037b88948de457e77f2875", null ],
    [ "CRAP_ENDIAN_BIG", "endianness_8h.html#ac1d9703e0f7c7dedb08e60ade9433f7c", null ],
    [ "CRAP_ENDIAN_ID", "endianness_8h.html#a7b04a4afd0319241617a17b6e4cee358", null ],
    [ "CRAP_ENDIAN_TYPE", "endianness_8h.html#a04c6231b23364c14b8f8cbaf370f2194", null ]
];