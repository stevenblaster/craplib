var structcrap_1_1limits_3_01u16_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01u16_01_4.html#aac89c7feebcee8d2995ad4f673bd2b2b", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01u16_01_4.html#a8b3d63b1536b733d7050d518cf81ae6a", null ],
    [ "MAX", "structcrap_1_1limits_3_01u16_01_4.html#afe9d8a17c2f0208f423347b1744ac06d", null ],
    [ "MIN", "structcrap_1_1limits_3_01u16_01_4.html#ac704c0d0f11c157ac4f1a4abd49c2bb8", null ]
];