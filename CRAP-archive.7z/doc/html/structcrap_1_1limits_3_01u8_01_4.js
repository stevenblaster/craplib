var structcrap_1_1limits_3_01u8_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01u8_01_4.html#a052fb6c41ae0f2fa6224b8bae28b9a89", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01u8_01_4.html#a13b8efd8c3d5fb1b35f62f656a52cb38", null ],
    [ "MAX", "structcrap_1_1limits_3_01u8_01_4.html#a0a25361a83b792daacb9fb54c2c1f2a2", null ],
    [ "MIN", "structcrap_1_1limits_3_01u8_01_4.html#a4a124feb65fbc522810c3e9c2fbb29ae", null ]
];