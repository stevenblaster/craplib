var structcrap_1_1limits_3_01f32_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01f32_01_4.html#a131c2fe141a0c04d5140850158a0cf2d", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01f32_01_4.html#a934f89c2f787b2d0f39a52ab4e0052b4", null ],
    [ "MAX", "structcrap_1_1limits_3_01f32_01_4.html#afea4f89ade14e316c4bb667d7647ca69", null ],
    [ "MIN", "structcrap_1_1limits_3_01f32_01_4.html#abf95b25d77cebc19337b8e65709f837d", null ]
];