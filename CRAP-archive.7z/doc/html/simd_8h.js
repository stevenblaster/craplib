var simd_8h =
[
    [ "CRAP_CONFIG_SIMD_H", "simd_8h.html#aad1aea991392ec09ef54c5202942cbae", null ],
    [ "CRAP_CPUID", "simd_8h.html#a7adf658547d2f56a83be4830ff7a86ca", null ],
    [ "CRAP_SIMD_AVX", "simd_8h.html#a84d03ac0fb78e67442f6cc059ca03ec9", null ],
    [ "CRAP_SIMD_AVX2", "simd_8h.html#a00b049295b5119cab002cebe37eaae81", null ],
    [ "CRAP_SIMD_NONE", "simd_8h.html#a602a2a579f28bdf9fc0ee6329a08e9a4", null ],
    [ "CRAP_SIMD_SSE", "simd_8h.html#a42e837036dd466104c235cc0046e94c0", null ],
    [ "CRAP_SIMD_SSE2", "simd_8h.html#af15292a2acf2108d8bd1d40f9fb2e3b0", null ],
    [ "CRAP_SIMD_SSE3", "simd_8h.html#aa08f61bf79f370719a4f05fd7b457d6c", null ],
    [ "CRAP_SIMD_SSE41", "simd_8h.html#af7c98bdafbb1331174550b2026edc594", null ],
    [ "CRAP_SIMD_SSE42", "simd_8h.html#ab5dda87ec0c50dc0be44dee817321a86", null ],
    [ "CRAP_SIMD_SSSE3", "simd_8h.html#a8b15b22008641cf298cb37cf25ed6367", null ],
    [ "CRAP_SIMD_VERSION", "simd_8h.html#adf313ed4a5f80ef58c3cbc45ab344c07", null ],
    [ "cpuid", "simd_8h.html#a62bfdd51e772a94b9fe3d67c13f224d0", null ],
    [ "eax", "simd_8h.html#aed325f6a8892f32051d8c544ae363a1d", null ],
    [ "ecx", "simd_8h.html#afe3d8527ce831ea0b8f9568c5c7deb52", null ],
    [ "esi", "simd_8h.html#a6e5ea7303bfa9d0671c2c69bcfb39331", null ],
    [ "mov", "simd_8h.html#a35f9ce3ce7462beeee43dbea46f2b509", null ]
];