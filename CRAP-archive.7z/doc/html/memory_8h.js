var memory_8h =
[
    [ "CRAP_CONFIG_MEMORY_H", "memory_8h.html#a6c407a6448d36daabcaeba4416ea43a1", null ],
    [ "CRAP_GARBAGE_COLLECTOR", "memory_8h.html#a76f5c5ecde940b058aa6fec1a7103d23", null ],
    [ "CRAP_GC_TICK", "memory_8h.html#a77aad550a67548322f09d6f455181f2d", null ],
    [ "CRAP_MEMORY_MANAGER", "memory_8h.html#af5048811917a1bea9ae9ed34e17f64e3", null ],
    [ "CRAP_MEMORY_TRACKER", "memory_8h.html#a2f03bc5b63031718649591fe736b77e6", null ]
];