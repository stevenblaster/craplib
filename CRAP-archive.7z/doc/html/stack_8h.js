var stack_8h =
[
    [ "stack", "classcrap_1_1stack.html", null ],
    [ "static_stack", "classcrap_1_1static__stack.html", "classcrap_1_1static__stack" ],
    [ "CRAP_CONTAINER_STATICSTACK_H", "stack_8h.html#a6a88ac031a399b142c1f27ca6c2aa36d", null ]
];