var structcrap_1_1zero_3_01f64_01_4 =
[
    [ "VALUE", "structcrap_1_1zero_3_01f64_01_4.html#a6467fb22f2cf48e955ddde385f23fac2", null ]
];