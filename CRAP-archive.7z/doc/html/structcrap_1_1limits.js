var structcrap_1_1limits =
[
    [ "IS_INT", "structcrap_1_1limits.html#a2e4a49dbaed009a912dece7de56da35e", null ],
    [ "IS_SIGNED", "structcrap_1_1limits.html#a1a2b5a6b5063ca03900e9c1955db561b", null ],
    [ "MAX", "structcrap_1_1limits.html#a757efc25bd4c43dd068be5ff95331afe", null ],
    [ "MIN", "structcrap_1_1limits.html#a0a11545145a7f4de4432d3956f1a2159", null ]
];