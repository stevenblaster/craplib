var structcrap_1_1binary__function =
[
    [ "first_argument_type", "structcrap_1_1binary__function.html#a9a31c99ac4accfc4336f5fcdd0f32c9f", null ],
    [ "result_type", "structcrap_1_1binary__function.html#a20fc043232aebcb7c1cacf6ed3cdca25", null ],
    [ "second_argument_type", "structcrap_1_1binary__function.html#ad778fde23d6c8d56c4e969eeae910211", null ]
];