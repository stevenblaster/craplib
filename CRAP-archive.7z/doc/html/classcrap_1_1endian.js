var classcrap_1_1endian =
[
    [ "byte_order", "classcrap_1_1endian.html#acd655732bc1be1cbc7614225510b06bc", [
      [ "little_endian", "classcrap_1_1endian.html#acd655732bc1be1cbc7614225510b06bcacaaaa395ded2e3f4b04bb7b9ddd1dcda", null ],
      [ "big_endian", "classcrap_1_1endian.html#acd655732bc1be1cbc7614225510b06bca50318490da9bb7fe3f2d5a6fab6c594e", null ]
    ] ],
    [ "big_to_local", "classcrap_1_1endian.html#ac455ef06416404e0e602fe5058249a76", null ],
    [ "check_endian", "classcrap_1_1endian.html#af4512bbd3646a2adb93f8e347cb91316", null ],
    [ "is_big", "classcrap_1_1endian.html#ac3f40e46feb16e0f256e0d575310a304", null ],
    [ "is_little", "classcrap_1_1endian.html#a1929d0b6d0fedf95e5ba224491fb73fa", null ],
    [ "little_to_local", "classcrap_1_1endian.html#a1acfd2485f4d14dce347366aa89732b3", null ],
    [ "swap", "classcrap_1_1endian.html#a90a0d30226be6645977d2a92e3e25eb8", null ],
    [ "swap_bytes", "classcrap_1_1endian.html#abb379815661f1c0bf53ff127a9e46ad2", null ],
    [ "to_big", "classcrap_1_1endian.html#a27273ac66da4bcb19b9d25487e3339fd", null ],
    [ "to_little", "classcrap_1_1endian.html#a74048f1ce4f5b78d758e9aa5e65e0bda", null ]
];