var processors_8h =
[
    [ "CRAP_CONFIG_PROCESSORS_H", "processors_8h.html#a1bfecc47b8cc638de5f6ef417730b717", null ],
    [ "CRAP_PROCESSOR_NAME", "processors_8h.html#ada3151f68592e02f42a0c159dad6ca05", null ],
    [ "CRAP_PROCESSOR_UNKNOWN", "processors_8h.html#ac8dd94dedb130718c3ecce853684bd0c", null ],
    [ "cpu", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978", [
      [ "x86", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978ad14cef82ed5566a888dd3f1b59845f89", null ],
      [ "x86_64", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978ab247c2e8e3c9f368c2e61fecff95204a", null ],
      [ "power_pc", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978a7dc08a3d279f643fec3992a335d486f6", null ],
      [ "ia64", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978a969503d77cdbfd85fd71b3da1b2911d1", null ],
      [ "arm", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978a1f322956c7af467490dfe02ad66b7ad4", null ],
      [ "unknown_cpu", "processors_8h.html#adc7591a3f0d0f8b064929e9b9feba978a4c435ee3ce75296a6d7bd519f00603cf", null ]
    ] ],
    [ "processor", "processors_8h.html#aa469741cd583ab37374123c2a9c7bae9", null ]
];