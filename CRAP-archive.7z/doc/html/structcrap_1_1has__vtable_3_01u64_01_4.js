var structcrap_1_1has__vtable_3_01u64_01_4 =
[
    [ "RESULT", "structcrap_1_1has__vtable_3_01u64_01_4.html#a1e6518eb5d447cc59d70934dfa7d3af1", null ]
];