var platforms_8h =
[
    [ "CRAP_CONFIG_PLATFORMS_H", "platforms_8h.html#a2d850503adb9f506644ce4552cb1bfe6", null ],
    [ "CRAP_PLATFORM_NAME", "platforms_8h.html#afe86fc088b0d61ec8c1ed2294754bea1", null ],
    [ "CRAP_PLATFORM_UNKNOWN", "platforms_8h.html#ae2d64b895cb8de27bc534c2f9cce9f78", null ],
    [ "os", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fd", [
      [ "platform_windows", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda0c640784849b6df0f3331dd2496499fa", null ],
      [ "platform_macintosh", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda638127da44361ae111082b4150307136", null ],
      [ "platform_ios", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda93bda5d1a82014723b1efe5f053d4d0b", null ],
      [ "platform_linux", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda23ed65cb4c48a5f5765ab5b8978fbcdc", null ],
      [ "platform_bsd", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fdac7cf11bbf8c16dda98d0d756df1e2ea5", null ],
      [ "platform_unix", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda2d1d2b6838c3fe48cb6beaf3cb23ae23", null ],
      [ "platform_unknown", "platforms_8h.html#a3ef4fad3b9a9befc38e0602d9b8323fda40a17798d2969201f9dbc4ffec789e91", null ]
    ] ],
    [ "platform", "platforms_8h.html#a7faa09b012c222545487156edff933a8", null ]
];