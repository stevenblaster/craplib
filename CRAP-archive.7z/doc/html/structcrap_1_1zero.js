var structcrap_1_1zero =
[
    [ "VALUE", "structcrap_1_1zero.html#adbf136ea6f7260ed699f6cbbb3a9ea46", null ]
];