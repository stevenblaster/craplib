var time_8h =
[
    [ "time", "classcrap_1_1time.html", "classcrap_1_1time" ],
    [ "time_info", "structcrap_1_1time_1_1time__info.html", "structcrap_1_1time_1_1time__info" ],
    [ "CRAP_CONTROL_TIME_H", "time_8h.html#aab48c1c5e99be9a2e36132a4ba201fdb", null ]
];