var structcrap_1_1has__vtable =
[
    [ "test_class", "structcrap_1_1has__vtable_1_1test__class.html", "structcrap_1_1has__vtable_1_1test__class" ],
    [ "RESULT", "structcrap_1_1has__vtable.html#a020726388c42488ee23dc65f8e1b4b83", null ]
];