var structcrap_1_1limits_3_01u32_01_4 =
[
    [ "IS_INT", "structcrap_1_1limits_3_01u32_01_4.html#a61391851a0c427911b85d1f820749120", null ],
    [ "IS_SIGNED", "structcrap_1_1limits_3_01u32_01_4.html#a4f3d08b60760db3e899e50e86f2c67b5", null ],
    [ "MAX", "structcrap_1_1limits_3_01u32_01_4.html#ab5ece5bb1f3672fc9eeb021079b0ea43", null ],
    [ "MIN", "structcrap_1_1limits_3_01u32_01_4.html#ae7af50ad2958496a562f706a503b29db", null ]
];